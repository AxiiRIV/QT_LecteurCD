#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>
#include "LecteurCD.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class LecteurVue;
}
QT_END_NAMESPACE

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(LecteurCD* pLecteur,QWidget *parent = nullptr);
    ~LecteurVue();

public:
    // Méthode de mise à jour d'interface
    void majInterfaceMarcheArret(Cellule::UnEtatMoteurCellule pEtatMoteur);
    void majInterfaceLecturePause(string pLabel);
    void ordreMajControlesTiroirEtLecture(LecteurCD::UnEtat pEtat);
    void ordreMajInfosTitreEnCours(string pIntitule = "-", int pRang = constantes::PAS_DE_TITRE);
    void ordreMajDureeTitreEnCours(int pDuree);
    void ordreMajinfosCD(string pIntitule = "-", string pPochette = "-", string pGenre = "-", int pDuree = 0, int pNbTitres = 0);

private slots:
    void demanderPauseOuPlay(); //met en pause/play
    void demanderArreter();
    void demanderSuivant();
    void demanderPrecedent();
    void demanderAuto();
    void demanderBoucle();
    void demanderAleatoire();
    void demanderOuvrirTiroir();
    void demanderFermerTiroir();
    void demanderInsertionCD(); //pour faire comme ci on insserait un cd...
    void demanderRetraitCD(); //pour faire comme ci on insserait un cd...


    /*======================================
     * AJOUT MANON 08/05/26
     * ===================================*/
    void demanderBasculerOnOff(bool pAllume); //réutilisation du concept de Vue, Presentation, Modele

    //au niveaux du son :
    void demanderChangervolume(int pVolume);
    void demanderActiverSon();
    void demanderDesactiverSon();



private:
    Ui::LecteurVue *ui;
    LecteurCD  *leLecteur;
    Cd *leCd;
};
#endif // LECTEURVUE_H
