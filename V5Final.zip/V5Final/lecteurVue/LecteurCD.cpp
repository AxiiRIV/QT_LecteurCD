#include "LecteurCD.h"
#include "lecteurvue.h"
#include <QDebug>

LecteurCD::LecteurCD(QObject *parent)
    : QObject(parent), monTiroirCD(this), laCellule(this), leSon(this)
{
    // Initialise le lecteurCD à l'état ETEINT
    setEtat(VIDE_ARRET);

    // Relier les composants Cellule (et son player) et sortieSon
    getLaCellule()->getPlayer()->setAudioOutput(getLeSon());

    // Régler le volume de la sortieSon
    leSon.setVolume(0.5);

    // Initialisation des attributs utilent pour la diffusion et l'affichage du titre en cours
    setTitreEnCours(nullptr);
    setRangTitreEnCours(constantes::PAS_DE_TITRE);

}

LecteurCD::~LecteurCD()
{
    delete this;
}

LecteurVue* LecteurCD::getVue()
{
    return laVue;
}


LecteurCD::UnEtat LecteurCD::getEtat()
{
    return etatLecteur;
}



TiroirCD* LecteurCD::getMonTiroirCD()
{
    return &monTiroirCD;
}

Cellule* LecteurCD::getLaCellule()
{
    return &laCellule;
}

SortieSon *LecteurCD::getLeSon()
{
    return &leSon;
}

LecteurCD::UnEtatModeLecture LecteurCD::getEtatModeLecture()
{
    return etatModeLecture;
}

int LecteurCD::getRangTitreEnCours()
{
    return rangTitreEnCours;
}

Titre *LecteurCD::getTitreEnCours()
{
    return titreEnCours;
}



void LecteurCD::setVue(LecteurVue *pVue)
{
    laVue = pVue;
}

/*void LecteurCD::setTiroirCD(TiroirCD& pTiroirCD)
{
    monTiroirCD = pTiroirCD;
}
*/


void LecteurCD::setEtat(UnEtat pEtat)
{
    etatLecteur = pEtat;
}

void LecteurCD::setEtatModeLecture(UnEtatModeLecture pEtatModeLecture)
{
    etatModeLecture = pEtatModeLecture;
}

LecteurCD::setTitreEnCours(Titre *pTitreEnCours)
{
    titreEnCours = pTitreEnCours;
}

LecteurCD::setRangTitreEnCours(int pRangTitreEnCours)
{
    rangTitreEnCours = pRangTitreEnCours;
}



void LecteurCD::changerVolume(int pVolume)
{
    leSon.setVolume(pVolume);
}

void LecteurCD::allumer()
{
    laCellule.demarrerLecture();
    /*qDebug() << "lecteur allumé "<< Qt::endl;
    etatLecteur=ALLUME;
    emit ChangerEtatLecteur(etatLecteur);
    //sigal envoyé par le modeèl/présentation à la vue.
*/

}

void LecteurCD::eteindre()
{
    laCellule.arreterLecture();
    /*qDebug() << "lecteur allumé "<< Qt::endl;
    etatLecteur=ETEINT;
    emit ChangerEtatLecteur(etatLecteur);
*/

}

void LecteurCD::arreter()
{
    qDebug()<< "Lecture arrétée. La lecture est reinitialisée!"<< Qt:: endl;

}

void LecteurCD::modeAleatoire()
{
    qDebug() << "Mode Aleatoire active" << Qt::endl;

    /*if (monCd != nullptr && monCd->getNbTitres() > 0)
    {
        // rand() génère un indice au hasard entre 0 et (nbTitres - 1) c'est bien pour aléatoire...
        // rand() % nb donne un nombre entre 0 et nb-1
        int indiceHasard = rand() % monCd->getNbTitres();

        //récupère le titre pris au hazard
        Titre t = monCd->getTitre(indiceHasard);

        qDebug() << "Lecture aleatoire de la piste :" << QString::fromStdString(t.getIntitule());
    }
*/
}

void LecteurCD::precedent()
{
    qDebug()<<"Musique precedante !"<< Qt:: endl;
    /*if (monCd != nullptr && monCd->getNbTitres() > 0)
    {
        // 1. Décrémenter l'index
        int positionActuelle = monCd->getPosition();
        positionActuelle--;

        // Sécurité : si on était à la première piste, on boucle à la fin
        if (positionActuelle < 0)
        {
            positionActuelle = monCd->getNbTitres() - 1;
        }

        // Récupérer le titre
        Titre t = monCd->getTitre(positionActuelle);


        etatLecteur = LECTURE;
    }
*/
}

void LecteurCD::suivant()
{
    qDebug()<<"Musique suivante !"<< Qt:: endl;
}

void LecteurCD::pauseOuLire()
{
    switch (this->getEtat()){
    case VIDE_ARRET: break;

    case OUVERT_ARRET: break;
    case LECTURE :
        qDebug() << "pause" << Qt::endl;
        setEtat(PAUSE);
        laVue->majInterfaceLecturePause("Pause");
        break;
    case CHARGE_ARRET :
        qDebug() << "lire" << Qt::endl;
        setEtat(LECTURE);
        laVue->majInterfaceLecturePause("Play");
        break;
    case PAUSE :
        qDebug() << "lire" << Qt::endl;
        setEtat(LECTURE);
        laVue->majInterfaceLecturePause("Play");
        break;
    default : break;
    }
}


void LecteurCD::modeBoucle()
{
    qDebug()<< "mode boucle activé"<< Qt::endl;

}

void LecteurCD::modeAuto()
{
    qDebug()<< "mode sequentiel activé"<< Qt::endl;

}

void LecteurCD::ouvrirTiroir()
{
    const QString PAS_DE_MEDIA_SOURCE = QString::fromStdString("");
    switch (this->getEtat()) {
    case VIDE_ARRET :
        qDebug() << "bouh" << Qt::endl;
        // actions métier
        getMonTiroirCD()->ouvrir();
        // changement d'état
        setEtat(OUVERT_ARRET);
        // ordres à destination de la Vue
        laVue->ordreMajControlesTiroirEtLecture(this->getEtat());
        break;
    case OUVERT_ARRET: break;
    case LECTURE:
        /* action_N */
            // actions métier
            getLaCellule()->arreterLecture();
            getMonTiroirCD()->ouvrir();
            setTitreEnCours(nullptr);
            setRangTitreEnCours(constantes::PAS_DE_TITRE);
            getLaCellule()->setSource(PAS_DE_MEDIA_SOURCE);
            // changement d'état
            setEtat(OUVERT_ARRET);
            // ordre de mise à jour de l'interface
            laVue->ordreMajInfosTitreEnCours();
            laVue->ordreMajDureeTitreEnCours(0);
            laVue->ordreMajControlesTiroirEtLecture(this->getEtat());

        break;
    case CHARGE_ARRET:
    case PAUSE:
        /* action_D */
            // actions métier
            getMonTiroirCD()->ouvrir();
            setTitreEnCours(nullptr);
            setRangTitreEnCours(constantes::PAS_DE_TITRE);
            getLaCellule()->setSource(PAS_DE_MEDIA_SOURCE);
            // changement d'état
            setEtat(OUVERT_ARRET);
            // ordres de mise à jour de l'interface
            laVue->ordreMajInfosTitreEnCours();
            laVue->ordreMajDureeTitreEnCours(0);
            laVue->ordreMajControlesTiroirEtLecture(this->getEtat());
        break;
    default: break;
    }
}

void LecteurCD::insererCd()
{
    switch (this->getEtat()) {
    case VIDE_ARRET : break;
    case OUVERT_ARRET :
        // si tiroir vide, on lui donne le cd sélécetionné:
        if(getMonTiroirCD()->getEtatOccupation()== TiroirCD::VIDE){
            // action_B :

            //action metier :
            //créer un cd et le peupler :
            Cd* leCd = new Cd();
            getMonTiroirCD()->peuplerCD(leCd);

            //associer le cd au tirroir :
            getMonTiroirCD()->insererCD(leCd);


            //changement d'état : il n'y en a pas

            //maj de l'interface:
            string sUrlFichier = DOSSIER_MEDIAS + getMonTiroirCD()->getLeCD()->getPochette();
            laVue->ordreMajinfosCD(getMonTiroirCD()->getLeCD()->getIntitule(), sUrlFichier,
                                    getMonTiroirCD()->getLeCD()->getGenre(),
                                    getMonTiroirCD()->getLeCD()->getDuree(),
                                    getMonTiroirCD()->getLeCD()->getNbTitres());
            // mettre à jour les boutons de contrôle de Tiroir CD et Lecture
            laVue->ordreMajControlesTiroirEtLecture(this->getEtat());

        }
        break;

    case LECTURE : break;
    case CHARGE_ARRET : break;
    case PAUSE : break;
    default:
        break;
    }

}

void LecteurCD::retirerCd()
{
    switch (this->getEtat()) {
    case VIDE_ARRET : break;
    case OUVERT_ARRET :
        // si tiroir vide, on lui donne le cd sélécetionné:
        if(getMonTiroirCD()->getEtatOccupation()== TiroirCD::OCCUPE){
            // action_B :

            //action metier :

            //associer le cd au tirroir :
            getMonTiroirCD()->retirerCD();


            //changement d'état : il n'y en a pas

            //maj de l'interface:
            laVue->ordreMajinfosCD();
            // mettre à jour les boutons de contrôle de Tiroir CD et Lecture
            laVue->ordreMajControlesTiroirEtLecture(this->getEtat());

        }
        break;

    case LECTURE : break;
    case CHARGE_ARRET : break;
    case PAUSE : break;
    default:
        break;
    }

}

void LecteurCD::fermerTiroir()
{
    switch (this->getEtat()) {
    case VIDE_ARRET : break;
    case OUVERT_ARRET:
        // si CD présent dans tiroir, action C_bis
        if (getMonTiroirCD()->getEtatOccupation() == TiroirCD::OCCUPE) {
            /* action_Cbis */
            // actions métier
            getMonTiroirCD()->fermer();

            setRangTitreEnCours(0);
            Titre* t = &(getMonTiroirCD()->getLeCD()->getTitres()[0]);
            setTitreEnCours(t);

            QString urlFichier = QString::fromStdString(DOSSIER_MEDIAS + getTitreEnCours()->getUrl());
            getLaCellule()->setSource(urlFichier);

            getLaCellule()->allerADebutMedia();

            // changer d'état
            setEtat(CHARGE_ARRET);

            // Maj de l'interface
            laVue->ordreMajInfosTitreEnCours(getTitreEnCours()->getIntitule(), getRangTitreEnCours()+1);
            laVue->ordreMajDureeTitreEnCours(getTitreEnCours()->getDuree());
            laVue->ordreMajControlesTiroirEtLecture(this->getEtat());
            laVue->majInterfaceLecturePause("Play");
        }
        else { // le tiroir est vide
            /* action_C */
            // actions métier
            getMonTiroirCD()->fermer();

            // changer d'état
            setEtat(VIDE_ARRET);

            // Maj de l'interface
            laVue->ordreMajinfosCD();
            laVue->ordreMajInfosTitreEnCours();
            laVue->ordreMajDureeTitreEnCours(0);
            laVue->ordreMajControlesTiroirEtLecture(this->getEtat());
        }
    case LECTURE: break;
    case CHARGE_ARRET: break;
    case PAUSE: break;
    default: break;
    }

}

void LecteurCD::activerSon()
{
    leSon.activerSon();
}

void LecteurCD::desactiverSon()
{
    leSon.desactiverSon();
}
