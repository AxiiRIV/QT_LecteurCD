#ifndef LECTEURCD_H
#define LECTEURCD_H

#include <QObject>
class LecteurVue;
class LecteurCD : public QObject
{
    Q_OBJECT
public:

    explicit LecteurCD(QObject *parent = nullptr);
    virtual ~LecteurCD();

    /* ---------
     * Lien avec la vue *
     * ------------------------------------------------*/
    LecteurVue* getVue();
    void setVue(LecteurVue* pVue);

public :

    /* ------------
     * méthodes déclenchées par des widgets de l'interface (= manipulation de l'utilisateur)
     * ----------------------------------------------------------------------------------*/
    void allumer();
    void eteindre();
    void lire ();
    void stop ();
    void pause();
    void precedent();
    void suivant();
    void debut();
    void ouvrirTiroir();
    void fermerTiroir();
    void insererCD();
    void retirerCD();

    // activés par les widgets permettant à l'utilisateur de choisir le mode de lecture
    void modeBoucle();
    void modeAuto();
    void modeAleatoire();

    // activés par les widgets permettant à l'utilisateur de gérer le son
    void activerSon();
    void desactiverSon();
    void majVolume(int pVolume);

    /* -----------
     * méthodes déclenchées par des interactions avec des éléments de menu de l'interface
     * -----------------------------------------------------------------------------*/
    void definirDossierMedias(std::string pDossier);

    /* -----------
     * Attributs de LecteurCD
     * -----------------------------*/
private:
    LecteurVue* laVue;          /* Pointeur vers la Vue.
                                   Implémente la relation Présentation --> Vue du framework MVP
                                    */
    std::string DOSSIER_MEDIAS = "C:/dev/sae2-IHM/CDs/"; // lieu dépôt des fichiers médias
};

#endif // LECTEURCD_H
