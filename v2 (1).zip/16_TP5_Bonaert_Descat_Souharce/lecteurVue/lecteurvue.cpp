#include "lecteurvue.h"
#include "ui_lecteurvue.h"
#include <QPixmap>
#include "lecteurcd.h"

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    // Connection des élements graphiques
    QObject:: connect(ui->bOnOff, SIGNAL(clicked()),this,SLOT(demanderAllumer()));
    QObject:: connect(ui->bOnOff, SIGNAL(clicked()),this,SLOT(demanderEteindre()));
    QObject::connect(ui->bOuvrirTiroir, SIGNAL(clicked()), this, SLOT(demanderOuvrirTiroir()));
    QObject::connect(ui->bFermerTiroir, SIGNAL(clicked()), this, SLOT(demanderFermerTiroir()));
    QObject::connect(ui->bInsererCD, SIGNAL(clicked()), this, SLOT(demanderInsererCD()));
    QObject::connect(ui->bRetirerCd, SIGNAL(clicked()), this, SLOT(demanderRetirerCD()));

    QObject:: connect(ui->bAuto, SIGNAL(clicked()),this,SLOT(demanderModeAuto()));
    QObject:: connect(ui->bPause, SIGNAL(clicked()),this,SLOT(demanderPause()));
    QObject:: connect(ui->bArreter, SIGNAL(clicked()),this,SLOT(demanderStop()));
    QObject:: connect(ui->bPrecedent, SIGNAL(clicked()),this,SLOT(demanderPrecedent()));
    QObject:: connect(ui->bSuivant, SIGNAL(clicked()),this,SLOT(demanderSuivant()));
    QObject:: connect(ui->bLire, SIGNAL(clicked()),this,SLOT(demanderLire()));
    QObject:: connect(ui->bBoucle, SIGNAL(clicked()),this,SLOT(demanderModeBoucle()));
    QObject:: connect(ui->bAleatoire, SIGNAL(clicked()),this,SLOT(demanderModeAleatoire()));
    QObject:: connect(ui->bDebut, SIGNAL(clicked()),this,SLOT(demanderDebut()));

    QObject::connect(ui->bActiverDesactSon, SIGNAL(clicked()), this, SLOT(demanderActiverSon()));
    QObject::connect(ui->bActiverDesactSon, SIGNAL(clicked()), this, SLOT(demanderDesactiverSon()));
    QObject:: connect(ui->slideSon, SIGNAL(valueChanged(int)),this,SLOT(demanderMajVolume(int)));



}

LecteurVue::~LecteurVue()
{
    delete ui;
}

LecteurCD *LecteurVue::getPresentation()
{
    return laPresentation;
}

void LecteurVue::setPresentation(LecteurCD *pPresentation)
{
    laPresentation = pPresentation;
}

void LecteurVue::demanderAllumer()
{
   laPresentation->allumer();
}

void LecteurVue::demanderEteindre()
{
    laPresentation->eteindre();
}

void LecteurVue::demanderLire()
{
    laPresentation->lire();
}

void LecteurVue::demanderStop()
{
    laPresentation->stop();
}

void LecteurVue::demanderPause()
{
    laPresentation->pause();
}


void LecteurVue::demanderSuivant()
{
    laPresentation->suivant();
}

void LecteurVue::demanderPrecedent()
{
    laPresentation->precedent();
}

void LecteurVue::demanderDebut()
{
    laPresentation->debut();
}

void LecteurVue::demanderOuvrirTiroir()
{
    laPresentation->ouvrirTiroir();
}

void LecteurVue::demanderFermerTiroir()
{
    laPresentation->fermerTiroir();
}


void LecteurVue::demanderInsererCD()
{
    laPresentation->insererCD();
}

void LecteurVue::demanderRetirerCD()
{
    laPresentation->retirerCD();
}

void LecteurVue::demanderActiverSon()
{
    laPresentation->activerSon();
}

void LecteurVue::demanderDesactiverSon()
{
    laPresentation->desactiverSon();
}

void LecteurVue::demanderMajVolume(int pVolume)
{
    laPresentation->majVolume(pVolume);
}

void LecteurVue::demanderModeAuto()
{
    laPresentation->modeAuto();
}

void LecteurVue::demanderModeBoucle()
{
    laPresentation->modeBoucle();
}

void LecteurVue::demanderModeAleatoire()
{
    laPresentation->modeAleatoire();
}





