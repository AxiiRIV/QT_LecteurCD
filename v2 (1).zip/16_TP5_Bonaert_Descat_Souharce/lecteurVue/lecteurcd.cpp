#include "lecteurcd.h"
#include "lecteurvue.h"

LecteurCD::LecteurCD(QObject *parent)
    : QObject{parent}
{}

LecteurCD::~LecteurCD()
{
    delete laVue;
}
LecteurVue *LecteurCD::getVue()
{
    return laVue;
}

void LecteurCD::setVue(LecteurVue *pVue)
{
    laVue = pVue;
}

void LecteurCD::allumer()
{
    qDebug() << "LectureCD : allumer" << Qt::endl;
}

void LecteurCD::eteindre()
{
    qDebug() << "LectureCD : eteindre" << Qt::endl;
}

void LecteurCD::lire()
{
    qDebug() << "LectureCD : lire" << Qt::endl;
}

void LecteurCD::stop()
{
    qDebug() << "LectureCD : stop" << Qt::endl;
}

void LecteurCD::pause()
{
    qDebug() << "LectureCD : pause" << Qt::endl;
}

void LecteurCD::precedent()
{
    qDebug() << "LectureCD : precedent" << Qt::endl;
}

void LecteurCD::suivant()
{
    qDebug() << "LectureCD : suivant" << Qt::endl;
}

void LecteurCD::debut()
{
    qDebug() << "LectureCD : debut" << Qt::endl;
}

void LecteurCD::ouvrirTiroir()
{
    qDebug() << "LectureCD : ouvrirTiroir" << Qt::endl;
}

void LecteurCD::fermerTiroir()
{
    qDebug() << "LectureCD : fermerTiroir" << Qt::endl;
}

void LecteurCD::insererCD()
{
    qDebug() << "LectureCD : insererCD" << Qt::endl;
}

void LecteurCD::retirerCD()
{
    qDebug() << "LectureCD : retirerCD" << Qt::endl;
}

void LecteurCD::modeBoucle()
{
    qDebug() << "LectureCD : modeBoucle" << Qt::endl;
}

void LecteurCD::modeAuto()
{
    qDebug() << "LectureCD : modeSequentiel" << Qt::endl;
}

void LecteurCD::modeAleatoire()
{
    qDebug() << "LectureCD : modeAleatoire" << Qt::endl;
}

void LecteurCD::activerSon()
{
    qDebug() << "LectureCD : activerSon" << Qt::endl;
}

void LecteurCD::desactiverSon()
{
    qDebug() << "LectureCD : desactiverSon" << Qt::endl;
}

void LecteurCD::majVolume(int pVolume)
{
    qDebug() << "changer volume"<< pVolume << Qt::endl;
    /*laVue->ui->setVolume(pVolume / 100.0);
    QString volumeString;
    volumeString.setNum(ui->sliderVolume->value());
    laVue->ui->lbVolumeActuel->setText(volumeString);*/
}

void LecteurCD::definirDossierMedias(std::string pDossier)
{
    DOSSIER_MEDIAS = pDossier;
}
