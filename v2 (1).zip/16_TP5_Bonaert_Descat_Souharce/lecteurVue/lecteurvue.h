#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class LecteurVue;
}
QT_END_NAMESPACE

class LecteurCD;
class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();

public:
    LecteurCD* getPresentation();
    void setPresentation(LecteurCD* pPresentation);
    void majInterface();
private slots:
    void demanderAllumer();
    void demanderEteindre();
    void demanderLire();
    void demanderStop();
    void demanderPause();
    void demanderSuivant();
    void demanderPrecedent();
    void demanderDebut();
    void demanderOuvrirTiroir();
    void demanderFermerTiroir();
    void demanderInsererCD();
    void demanderRetirerCD();
    void demanderActiverSon();
    void demanderDesactiverSon();
    void demanderMajVolume(int pVolume);
    void demanderModeAuto(); // équivalent au mode séquentiel
    void demanderModeBoucle();
    void demanderModeAleatoire();

private:
    Ui::LecteurVue *ui;
    LecteurCD* laPresentation;

};
#endif // LECTEURVUE_H
