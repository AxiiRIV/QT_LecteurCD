#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>
#include "LecteurCD.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class LecteurVue;
}
QT_END_NAMESPACE

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();

public:
    void majInterfaceMarcheArret(Cellule::UnEtatMoteurCellule pEtatMoteur);
    void majInterfaceLecturePause(LecteurCD::UnEtat pEtat);
private slots:
    void demanderPauseOuPlay(); //met en pause/pay
    void demanderArreter();
    void demanderSuivant();
    void demanderPrecedent();
    void demanderAuto();
    void demanderBoucle();
    void demanderAleatoire();
    void demanderOuvrirTiroir();
    void demanderFermerTiroir();
    void demanderInsertionCD(); //pour faire comme ci on insserait un cd...
    void demanderRetraitCD(); //pour faire comme ci on insserait un cd...


    /*======================================
     * AJOUT MANON 08/05/26
     * ===================================*/
    void demanderBasculerOnOff(bool pAllume); //réutilisation du concept de Vue, Presentation, Modele

    //au niveaux du son :
    void demanderChangervolume(int pVolume);
    void demanderActiverSon();
    void demanderDesactiverSon();



private:
    Ui::LecteurVue *ui;
    LecteurCD  *leLecteur;
    Cd *leCd;
};
#endif // LECTEURVUE_H
