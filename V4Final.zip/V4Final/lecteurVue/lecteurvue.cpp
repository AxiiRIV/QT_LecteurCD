#include "lecteurvue.h"
#include "LecteurCD.h"
#include "ui_lecteurvue.h"
#include <QPixmap>
#include <cd.h>//on en a besoin pour recupérer les données du cd....



LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::LecteurVue)
{
    ui->setupUi(this);
    leLecteur = new LecteurCD();
    majInterfaceMarcheArret(leLecteur->getLaCellule()->getEtatMoteur()); // met l'interface inactive de base pour dire que c'est eteint.

    QObject::connect(ui->BOnOff, SIGNAL(toggled(bool)), this, SLOT(demanderBasculerOnOff(bool)));
    QObject:: connect(ui->bAleatoire, SIGNAL(clicked()), this, SLOT(demanderAleatoire()));
    QObject:: connect(ui->bAuto, SIGNAL(clicked()),this,SLOT(demanderAuto()));
    QObject:: connect(ui->bPause, SIGNAL(clicked()),this,SLOT(demanderPauseOuPlay()));
    QObject:: connect(ui->bPrecedent, SIGNAL(clicked()),this,SLOT(demanderPrecedent()));
    QObject:: connect(ui->bSuivant, SIGNAL(clicked()),this,SLOT(demanderSuivant()));
    QObject:: connect(ui->bArreter, SIGNAL(clicked()),this,SLOT(demanderArreter()));
    QObject:: connect(ui->bBoucle, SIGNAL(clicked()),this,SLOT(demanderBoucle()));
    QObject:: connect(ui->BOuvrirTiroir, SIGNAL(clicked()),this,SLOT(demanderOuvrirTiroir()));
    QObject:: connect(ui->BFermerTiroir, SIGNAL(clicked()),this,SLOT(demanderFermerTiroir()));
    QObject:: connect(ui->BIncererCD, SIGNAL(clicked()), this, SLOT(demanderInsertionCD()));
    QObject:: connect(ui->BRetirerCd, SIGNAL(clicked()), this, SLOT(demanderRetraitCD())); //pour faire comme ci on insserait un cd...
    QObject:: connect(ui->BActiverSon, SIGNAL(clicked()), this, SLOT(demanderActiverSon())); // le boutton radion n'est pas conmpatible donc il faute 2 bouttons et ses methodes....
    QObject:: connect(ui->BDesactiverSon, SIGNAL(clicked()), this, SLOT(demanderDesactiverSon()));

    QObject::connect(ui->SlideSon, SIGNAL(valueChanged(int)), this, SLOT(demanderChangervolume(int)));

}

void LecteurVue::majInterfaceMarcheArret(Cellule::UnEtatMoteurCellule pEtatMoteur)
{
    switch (pEtatMoteur) {
    case  Cellule::ARRET:

        //changemtn des informations du cd
        ui->LbintituleCD->setText("Lecteur éteint !");
        ui->LbintituleMusique->setText("-");
        ui->LbTempTotMusic->setText("--.--");
        ui->LbTmpActMusic->setText("--.--");
        ui->LbrangTitre->setText("-");
        ui->LbnbTitres->setText("-");

        //changement des boutons du tirroir :
        ui->BOuvrirTiroir->setEnabled(false);
        ui->BFermerTiroir->setEnabled(false);
        ui->BIncererCD->setEnabled(false);
        ui->BRetirerCd->setEnabled(false);

        //changement de l'etat du bouton du son :
        ui->SlideSon->setEnabled(false);
        ui->BActiverSon->setEnabled(false);
        ui->BDesactiverSon->setEnabled(false);

        //changement des etats des boutons d'actions sur la musique
        ui->bArreter->setEnabled(false);
        ui->bAuto->setEnabled(false);
        ui->bBoucle->setEnabled(false);
        ui->bPause->setEnabled(false);
        ui->bSuivant->setEnabled(false);
        ui->bPrecedent->setEnabled(false);

        break;

    case Cellule::MARCHE :
        //changemtn des informations du cd
        ui->LbintituleCD->setText("Lecteur allumé !");
        ui->LbintituleMusique->setText("-");
        ui->LbTempTotMusic->setText("--.--");
        ui->LbTmpActMusic->setText("--.--");
        ui->LbrangTitre->setText("-");
        ui->LbnbTitres->setText("-");

        //changement des boutons du tirroir :
        ui->BOuvrirTiroir->setEnabled(true);
        ui->BFermerTiroir->setEnabled(false);//le tirroir reste fermé quand on allume le lecteur.
        ui->BIncererCD->setEnabled(false); //pas possible d'incerer un cd tant qu'on a pas ouver le tirroir.
        ui->BRetirerCd->setEnabled(false); //pas possible de retirer un cd tant qu'on a pas ouver le tirroir.

        //changement de l'etat du bouton du son :
        ui->SlideSon->setEnabled(true);
        ui->BActiverSon->setEnabled(false);
        //le son est déjà activé donc pas besoin de l'activer...
        //Boutton est utille que si on desacitve le son....
        ui->BDesactiverSon->setEnabled(true);


        //changement des etats des boutons d'actions sur la musique
        //rien n'est activé à ce niveau là tant qu'il n'y a pas de cd.
        ui->bArreter->setEnabled(false);
        ui->bAuto->setEnabled(false);
        ui->bBoucle->setEnabled(false);
        ui->bPause->setEnabled(false);
        ui->bSuivant->setEnabled(false);
        ui->bPrecedent->setEnabled(false);
        break;

    default:
        break;
    }
}

void LecteurVue::majInterfaceLecturePause(LecteurCD::UnEtat pEtat)
{
    switch (pEtat){
    case LecteurCD::LECTURE:
        ui->bPause->setText("Pause");
        break;


    case LecteurCD::PAUSE:
        ui->bPause->setText("Play");
        break;

    case LecteurCD::VIDE_ARRET :
        break;
    case LecteurCD::OUVERT_ARRET :
        break;
    case LecteurCD::CHARGE_ARRET :
        break;
    default: break;
    }
}


LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::demanderBasculerOnOff(bool pAllume)
{
    if (pAllume) {
        qDebug() << "Allumage demande...";
        leLecteur->allumer();
        majInterfaceMarcheArret(leLecteur->getLaCellule()->getEtatMoteur());
    } else {
        qDebug() << "Extinction demandee...";
        leLecteur->eteindre();
        majInterfaceMarcheArret(leLecteur->getLaCellule()->getEtatMoteur());
    }
}

void LecteurVue::demanderPauseOuPlay()
{
    //faire un switch en fonction de l'etat du boutton
    //changer l'apparence du boutton !
    // Si le bouton est enfoncé (checked), on joue, sinon on met en pause
    if (ui->bPause->isChecked()) {
        leLecteur->pauseOuLire();
        ui->bPause->setText("Pause");
    } else {
        leLecteur->pauseOuLire();
        ui->bPause->setText("Play");
    }

}

void LecteurVue::demanderArreter()
{
    qDebug() << " lectureVue : bouton <bArreter> cliqué" << Qt ::endl ;
    leLecteur->arreter();
}

void LecteurVue::demanderSuivant()
{
    qDebug() << " lectureVue : bouton <bSuivant> cliqué" << Qt ::endl ;
    leLecteur->suivant();
}

void LecteurVue::demanderPrecedent()
{
    qDebug() << " lectureVue : bouton <bPrecedent> cliqué" << Qt ::endl ;
    leLecteur->precedent();
}

void LecteurVue::demanderAuto()
{
    qDebug() << " lectureVue : bouton <bAuto> cliqué" << Qt ::endl ;
    leLecteur->modeAuto();
}

void LecteurVue::demanderBoucle()
{
    qDebug() << " lectureVue : bouton <bBoucle> cliqué" << Qt ::endl ;
    leLecteur->modeBoucle();
}

void LecteurVue::demanderAleatoire()
{
    qDebug() << " lectureVue : bouton <bAleatoire> cliqué" << Qt ::endl ;
    leLecteur->modeAleatoire();
}

void LecteurVue::demanderOuvrirTiroir()
{
    leLecteur->ouvrirTiroir();
    ui->BIncererCD->setEnabled(true); //comme le tiroir est ouver, on peut incerer le cd.
    ui->BRetirerCd->setEnabled(true); // pareil.
    ui->BFermerTiroir->setEnabled(true); // on peut aussi le fermer ducoup...
}

void LecteurVue::demanderFermerTiroir()
{
    leLecteur->fermerTiroir();
    ui->BIncererCD->setEnabled(false); //comme le tiroir est fermé, on peut pas retirer le cd.
    ui->BRetirerCd->setEnabled(false); // il n'y a pas de cd à retirer. on vient de fermer le tiroir.

    leCd = leLecteur->getMonTiroirCD()->getLeCD(); // La Vue récupère les données du cd de lecteurCd.h/.cpp

    if(leCd != nullptr && leCd->getNbTitres() > 0) //là, on voit juste si le cd est là et qu'il a des tires...
    {
        //changement des etats des bouttons :
        // boutons d'insertion/retrait puisque le tiroir est fermé
        ui->BIncererCD->setEnabled(false);
        ui->BRetirerCd->setEnabled(false);

        //si le cd est ok : on peut utiliser les bouttons d'action
        ui->bArreter->setEnabled(true);
        ui->bPause->setEnabled(true);
        ui->bSuivant->setEnabled(true);
        ui->bPrecedent->setEnabled(true);
        ui->bAuto->setEnabled(true);
        ui->bBoucle->setEnabled(true);

        // Mise à jour des informations sur l'interface :

        majInterfaceLecturePause(LecteurCD::PAUSE);
        //Le lecteur se met en mote arret car il a recupéré le cd et il est allumé.
        //le boutton pause va alors devenir le boutton plays et on va pouvoir démarer la lecture du cd.

        // modificationd des labels :
        ui->LbintituleCD->setText(QString::fromStdString(leCd->getIntitule()));
        ui->LbnbTitres->setText(QString::number(leCd->getNbTitres()) + " titres"); //"tires"juste pour faire mieux
        ui->LbTempTotMusic->setText(QString::number(leCd->getDuree()) + " s"); // pareil...

        Titre t = leCd->getTitre(0);
        ui->LbintituleMusique->setText(QString::fromStdString(t.getIntitule()));
        //sert de tampon temporel pour traiter le titre actuel. il sera deruit à la fin de cette methode.

        // La pochette prend l'image du cd.
        //attention ça march pas!!!!
        QPixmap laPochette(QString::fromStdString(leCd->getPochette()));
        ui->lbPochette->setPixmap(laPochette.scaled(ui->lbPochette->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }
    else
    {
        // Si pas de CD, on affiche un message vide
        ui->LbintituleCD->setText("Pas de disque");
        ui->BIncererCD->setEnabled(true); // On laisse la possibilité d'insérer si c'est vide
    }
}



void LecteurVue::demanderInsertionCD()
{
    leLecteur->insererCd();
    ui->BIncererCD->setEnabled(false); //si t'as déjà inceré un cd, tu vas pas en incérer un autre....
    ui->BRetirerCd->setEnabled(true);
}

void LecteurVue::demanderRetraitCD()
{
    leLecteur->retirerCd();
    ui->BIncererCD->setEnabled(true);
    ui->BRetirerCd->setEnabled(false); //si t'as déjà retirer un cd, tu vas pas en retirer un autre....
}

void LecteurVue::demanderChangervolume(int pVolume)
{
    qDebug() << "lectureVue : envoie de la demande de changer de volume au lecteurCD"<< Qt ::endl ;
    leLecteur->changerVolume(pVolume);
    // On met à jour le label du volume que en chiffre...
    ui->LVolumeActuel->setText(QString::number(pVolume));
}

void LecteurVue::demanderActiverSon()
{
    qDebug() << "LectureVue : le boutton d'activation du son est solicité.";
    leLecteur->activerSon();
    ui->SlideSon->setEnabled(true);
    ui->BActiverSon->setEnabled(false);
}

void LecteurVue::demanderDesactiverSon()
{
    qDebug() << "LectureVue : le boutton de desactivation du son est solicité.";
    leLecteur->desactiverSon();
    ui->SlideSon->setEnabled(false);
    ui->BDesactiverSon->setEnabled(false);
    ui->BActiverSon->setEnabled(true);

}




