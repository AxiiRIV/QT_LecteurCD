#include "LecteurCD.h"
#include "lecteurvue.h"
#include <QDebug>

LecteurCD::LecteurCD(QObject *parent)
    : QObject(parent), monTiroirCD(this), laCellule(this), leSon(this)
{
    // Initialise le lecteurCD à l'état ETEINT
    setEtat(VIDE_ARRET);

    // Relier les composants Cellule (et son player) et sortieSon
    getLaCellule()->getPlayer()->setAudioOutput(getLeSon());

    // Régler le volume de la sortieSon
    leSon.setVolume(0.5);

}

LecteurCD::~LecteurCD()
{
    delete this;
}

LecteurVue* LecteurCD::getVue()
{
    return laVue;
}

bool LecteurCD::getModeBoucle()
{
    return estEnBoucle;
}

bool LecteurCD::getModeAuto()
{
    return estEnAuto;
}

bool LecteurCD::getModeAleatoire()
{
    return estEnAleatoire;
}

LecteurCD::UnEtat LecteurCD::getEtat()
{
    return etatLecteur;
}



TiroirCD* LecteurCD::getMonTiroirCD()
{
    return &monTiroirCD;
}

Cellule* LecteurCD::getLaCellule()
{
    return &laCellule;
}

SortieSon *LecteurCD::getLeSon()
{
    return &leSon;
}



void LecteurCD::setVue(LecteurVue *pVue)
{
    laVue = pVue;
}

/*void LecteurCD::setTiroirCD(TiroirCD& pTiroirCD)
{
    monTiroirCD = pTiroirCD;
}
*/


void LecteurCD::setEtat(UnEtat pEtat)
{
    etatLecteur = pEtat;
}



void LecteurCD::changerVolume(int pVolume)
{
    leSon.setVolume(pVolume);
}

void LecteurCD::allumer()
{
    laCellule.demarrerLecture();
    /*qDebug() << "lecteur allumé "<< Qt::endl;
    etatLecteur=ALLUME;
    emit ChangerEtatLecteur(etatLecteur);
    //sigal envoyé par le modeèl/présentation à la vue.
*/

}

void LecteurCD::eteindre()
{
    laCellule.arreterLecture();
    /*qDebug() << "lecteur allumé "<< Qt::endl;
    etatLecteur=ETEINT;
    emit ChangerEtatLecteur(etatLecteur);
*/

}

void LecteurCD::arreter()
{
    qDebug()<< "Lecture arrétée. La lecture est reinitialisée!"<< Qt:: endl;

}

void LecteurCD::modeAleatoire()
{
    qDebug() << "Mode Aleatoire active" << Qt::endl;

    /*if (monCd != nullptr && monCd->getNbTitres() > 0)
    {
        // rand() génère un indice au hasard entre 0 et (nbTitres - 1) c'est bien pour aléatoire...
        // rand() % nb donne un nombre entre 0 et nb-1
        int indiceHasard = rand() % monCd->getNbTitres();

        //récupère le titre pris au hazard
        Titre t = monCd->getTitre(indiceHasard);

        qDebug() << "Lecture aleatoire de la piste :" << QString::fromStdString(t.getIntitule());
    }
*/
}

void LecteurCD::precedent()
{
    qDebug()<<"Musique precedante !"<< Qt:: endl;
    /*if (monCd != nullptr && monCd->getNbTitres() > 0)
    {
        // 1. Décrémenter l'index
        int positionActuelle = monCd->getPosition();
        positionActuelle--;

        // Sécurité : si on était à la première piste, on boucle à la fin
        if (positionActuelle < 0)
        {
            positionActuelle = monCd->getNbTitres() - 1;
        }

        // Récupérer le titre
        Titre t = monCd->getTitre(positionActuelle);


        etatLecteur = LECTURE;
    }
*/
}

void LecteurCD::suivant()
{
    qDebug()<<"Musique suivante !"<< Qt:: endl;
}

void LecteurCD::pauseOuLire()
{
    switch (this->getEtat()){
    case VIDE_ARRET:
        qDebug() << "Impossible à lire pas de CD" << Qt::endl;
        break;

    case OUVERT_ARRET:
        qDebug() << "Impossible à lire pas de CD" << Qt::endl;
        break;
    case LECTURE :
        qDebug() << "pause" << Qt::endl;
        setEtat(PAUSE);
        break;
    case CHARGE_ARRET :
        qDebug() << "lire" << Qt::endl;
        setEtat(LECTURE);
        break;
    case PAUSE :
        qDebug() << "lire" << Qt::endl;
        setEtat(LECTURE);
        break;
    default : break;
    }
}


void LecteurCD::modeBoucle()
{
    qDebug()<< "mode boucle activé"<< Qt::endl;

    //je préfère le faire comme ça...
    estEnBoucle = true;
    estEnAuto = false;
    estEnAleatoire = false;

    qDebug() << "Mode boucle :" << estEnBoucle;
}

void LecteurCD::modeAuto()
{
    qDebug()<< "mode sequentiel activé"<< Qt::endl;
    estEnBoucle = false;
    estEnAuto = true;
    estEnAleatoire = false;
}

void LecteurCD::ouvrirTiroir()
{
    monTiroirCD.ouvrir();
    setEtat(OUVERT_ARRET);
}

void LecteurCD::insererCd()
{
    monTiroirCD.insererCD(monTiroirCD.getLeCD());
    setEtat(CHARGE_ARRET);

}

void LecteurCD::retirerCd()
{
    monTiroirCD.retirerCD();
    setEtat(VIDE_ARRET);

}

void LecteurCD::fermerTiroir()
{
    monTiroirCD.fermer();
    // Cela sera modifié lors du livrable 9, c'est pour l'instant fait comme cela pour faire fonctionner l'application
    if(getEtat() == VIDE_ARRET){

    }
    else if (getEtat() == OUVERT_ARRET){
        setEtat(VIDE_ARRET);
    }
    else if (getEtat() == CHARGE_ARRET){

    }

}

void LecteurCD::activerSon()
{
    leSon.activerSon();
}

void LecteurCD::desactiverSon()
{
    leSon.desactiverSon();
}
