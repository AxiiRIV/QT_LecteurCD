#ifndef LECTEURCD_H
#define LECTEURCD_H

#include <QObject>
#include "tiroircd.h"
#include "cellule.h"
#include "sortieson.h"


using namespace std;

class LecteurVue;
class LecteurCD : public QObject
{
    Q_OBJECT // marco pour utilisez des signaux/slots plus tard

public:
     LecteurCD(QObject *parent = nullptr);
    ~LecteurCD(); // destructeur

    // Déclaration type
    enum UnEtat {LECTURE, PAUSE,VIDE_ARRET,OUVERT_ARRET,CHARGE_ARRET};
    // va donner les differents états possible pour l'état du lecteur cd (Eteint ou allumé)
    // on a rajouté deux nouveaux états LECTURE et ARRET pour faire des choses avec la lecture du cd.
    //pour pouvoir lire les cd. comme un vrai lecteur.

    // getters
    LecteurVue* getVue();
    bool getModeBoucle();
    bool getModeAuto();
    bool getModeAleatoire();
    UnEtat getEtat();
    TiroirCD* getMonTiroirCD();
    Cellule* getLaCellule(); // sert à recupérer la Cellule pour savoir si la cellule est bien connectée.
    SortieSon* getLeSon();

    // setter
    void setVue(LecteurVue* pVue);
    //void setTiroirCD(TiroirCD& pTiroirCD);
    void setEtat(UnEtat pEtat);

    // explicit LecteurCD(UnEtat pEtat = ETEINT, QObject *parent = nullptr);
    //met par defaut le lecteur eteint.

    void changerVolume(int); //sera utilisé pour changer le volume
    void allumer();//allumer le lecteur
    void eteindre(); //etient le lecteur

    //actions des bouttons de la barres des actions sur la ecture :
    void arreter(); //arrete la lecture totalement et met à 0 la lecture du cd.
    void pauseOuLire();
    void modeBoucle(); //mode boucle
    void modeAuto(); //mode auto
    void modeAleatoire(); //mode aléatoire.
    void precedent();
    void suivant();

    //action de chargemant du lecteur avec l'objet cd :
    void ouvrirTiroir();
    // va simplement rendre possible l'action d'incerer le cd ou de le retirer et de le fermer aussi....

    void insererCd(); // mettra le cd (objet cd) dans le lecteru pour etre lu.
    void retirerCd(); // retire le cd.

    void fermerTiroir(); // ferme le tiroir du lecteur et là il y aura deux possibilités :
    //si un cd est présent et contien des titres, il va tout faire apparaitre et modifier les QLabels de l'aplication.
    //si non, il indiquera que le cd est vide, non lu, ou que le tiroir est vide.

    void activerSon(); //permet d'activer le son et avoir acces au slide button.
    void desactiverSon(); //rend le slide innaccessible et coupe le son des hautparleurs.

private:
    LecteurVue *laVue; // Pointeur vers la vue donc la classe LecteurVue
    TiroirCD monTiroirCD; // Un des éléments du lecteur CD pour lire le CD.
    Cellule laCellule; // Un des éléments du lecteur CD pour l'allumer et l'éteindre
    SortieSon leSon; // Un des éléments du lecteur CD pour gérer le son

    UnEtat etatLecteur;
    //à utiliser pour déclarer l'etat du lecteur pour permettre l'utilisation des services de ce dernier

    //etats des modes de lectures : utiles pour les 3 modes possibles (boucle, sequentiel et aléatoire)
    bool estEnBoucle = false;
    bool estEnAleatoire = false;
    bool estEnAuto = false;

signals :
    void ChangerEtatLecteur(LecteurCD::UnEtat nouvelEtat);
    // Le signal pour prévenir la vue que l'etat change si non ça crache....

};

#endif // LECTEURCD_H
